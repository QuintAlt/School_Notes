document.addEventListener('DOMContentLoaded', () => {
  const balaozinho = document.getElementById('balaozinho');
  const marcacoes = document.querySelectorAll('.marcacao');
  const foto = document.querySelector('.foto-anotada');

  if (!balaozinho || !foto) return;

  // For each marcacao attach events
  marcacoes.forEach((m) => {
    // Exercise 1 + 3: when mouse enters, fill with proper title/content
    m.addEventListener('mouseenter', (ev) => {
      const titulo = m.dataset.titulo || 'Sem título';
      const conteudo = m.dataset.conteudo || '';
      balaozinho.innerHTML = '<h2>' + titulo + '</h2><p>' + conteudo + '</p>';
      balaozinho.style.display = 'block';
    });

    // When leaving, clear
    m.addEventListener('mouseleave', () => {
      balaozinho.innerHTML = '';
      balaozinho.style.display = 'none';
    });

    // Exercise 4: move balaozinho to follow mouse (positioned relative to photo)
    m.addEventListener('mousemove', (ev) => {
      const fotoRect = foto.getBoundingClientRect();
      // clientX/Y are relative to viewport; convert to position inside .foto-anotada
      const x = ev.clientX - fotoRect.left + 10; // offset a bit to avoid overlapping cursor
      const y = ev.clientY - fotoRect.top + 10;
      balaozinho.style.left = x + 'px';
      balaozinho.style.top = y + 'px';
    });
  });

  // Exercise 5: update first marcacao from inputs when button clicked
  const btn = document.getElementById('definir-marcacao');
  const primeira = document.querySelector('.marcacao');
  const inX = document.getElementById('marcacao-x');
  const inY = document.getElementById('marcacao-y');
  const inW = document.getElementById('marcacao-largura');
  const inH = document.getElementById('marcacao-altura');

  if (btn && primeira && inX && inY && inW && inH) {
    btn.addEventListener('click', () => {
      // apply values (assume pixels)
      primeira.style.left = inX.value + 'px';
      primeira.style.top = inY.value + 'px';
      primeira.style.width = inW.value + 'px';
      primeira.style.height = inH.value + 'px';
    });
  }
});



/*

electrode:

x 325
y 190
largura 165
altura 155

*/