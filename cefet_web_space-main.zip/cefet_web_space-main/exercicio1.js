// Faça o exercício da equação de GRAVITAÇÃO UNIVERSAL aqui
// Este arquivo AINDA NÃO ESTÁ INCLUÍDO no arquivo HTML

document.addEventListener("DOMContentLoaded", function () {
    const botao = document.getElementById("calcular");
    const campoConstante = document.getElementById("constante");
    const campoMassa1 = document.getElementById("massa1");
    const campoMassa2 = document.getElementById("massa2");
    const campoDistancia = document.getElementById("distancia");
    const campoResultado = document.getElementById("resultado");
  
    botao.addEventListener("click", function () {
      const G = parseFloat(campoConstante.value);
      const M1 = parseFloat(campoMassa1.value);
      const M2 = parseFloat(campoMassa2.value);
      const d = parseFloat(campoDistancia.value);
  
      if (isNaN(M1) || isNaN(M2) || isNaN(d) || d === 0) {
        campoResultado.value = "";
        alert("Preencha todos os valores corretamente (distância não pode ser 0).");
        return;
      }
  
      const F = (G * M1 * M2) / (d * d);
      campoResultado.value = F;
    });
  });
  