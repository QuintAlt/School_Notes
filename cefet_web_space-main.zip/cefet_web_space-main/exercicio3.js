// Faça o exercício dos PARÁGRAFOS aqui
// Este arquivo AINDA NÃO ESTÁ INCLUÍDO no arquivo HTML

const botoes = document.querySelectorAll('.botao-expandir-retrair');

botoes.forEach((botao) => {
  botao.addEventListener('click', (e) => {
    const p = e.currentTarget.parentElement; // o <p> que contém o botão
    p.classList.toggle('expandido'); // alterna expandir/retrair
    
    // alterna o texto do botão
    if (p.classList.contains('expandido')) {
      e.currentTarget.innerHTML = '-';
    } else {
      e.currentTarget.innerHTML = '+';
    }
  });
});
